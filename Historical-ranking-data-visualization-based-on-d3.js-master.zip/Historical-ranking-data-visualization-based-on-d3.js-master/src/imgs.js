var external_imgs = {
    "label1": "img/path/for/label1",
    "label2": "img/path/for/label2"
}