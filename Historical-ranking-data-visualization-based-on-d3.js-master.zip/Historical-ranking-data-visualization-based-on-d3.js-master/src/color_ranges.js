config.color_ranges = {
  'label1': ['#3a6073', '#3a7bd5'],
  'label2': ['#11998e', '#38ef7d'],
};